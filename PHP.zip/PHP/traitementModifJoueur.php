<?php
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'fonctions.php';
    
    // Récupération des données du formulaire
    $Joueur = array(
    'j_id' => $_POST['id'],
    'nom' => $_POST['nom'],
    'prenom' => $_POST['prenom'],
    'date' => $_POST['date'],
    'poste' => $_POST['poste'],
    'role' => $_POST['role']
);
if (isset($_POST['nom'])) {
    $Joueur['nom'] = $_POST['nom'];
}


    
    // Insertion des données dans la base de données
    $Joueur['j_id'] = (int)substr($Joueur['j_id'], 0, 13); // Cast j_id to an integer
    $resultat = updateP13_Joueur($Joueur);
    
    // Affichage d'un message de confirmation
    if(isset($resultat['j_id'])) {
    echo "Le joueur a été modifiée avec succès.";
    echo '<br><a href="tableAcceuilJoueur.php">Retourner à la liste des joueurs</a>';
} else {
    echo "Une erreur est survenue lors de la modification du joueur.";
    echo '<br><a href="tableAcceuilJoueur.php">Retourner à la liste des joueurs</a>';
}
}
?>