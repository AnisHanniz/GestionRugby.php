<?php
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'fonctions.php';
    
    // Récupération des données du formulaire
    $Joueur = array(
        'j_id' => (int)$_POST['id'],
        'nom' => $_POST['nom'],
        'prenom' => $_POST['prenom'],
        'date_naissance' => $_POST['date'],
        'poste_id' => (int)$_POST['poste'],
        'role' => $_POST['role']);
    $asso = array(
        'eq_id' => getId_ByEquipe($_POST['Equipe']),
        'j_id' => (int)$_POST['id'],
        'date_debut_contrat' => $_POST['dateDC'],
        'date_fin_contrat' => $_POST['dateFC']
    );
    // Insertion des données dans la base de données
    $Joueur['j_id'] = (int)substr($Joueur['j_id'], 0, 13); // Cast j_id to an integer
    $resultat = insertP13_Joueur($Joueur);
    $resultat2 = insertP13_jouer($asso);
    
    // Affichage d'un message de confirmation
    if(isset($resultat['j_id'])) {
        echo "Le joueur a été ajouté avec succès.";
        echo '<br><a href="tableAcceuilJoueur.php">Retourner à la liste des joueurs</a>';
    } else {
        echo "Une erreur est survenue lors de l'ajout du joueur.";
        echo '<br><a href="tableAcceuilJoueur.php">Retourner à la liste des joueurs</a>';
    }
}
?>