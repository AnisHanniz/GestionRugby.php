<?php
require 'fonctions.php';



$pageHTML = getDebutHTML("Jouer", "style");

// ajout d'un titre
$pageHTML .= '<h1>Table Jouer</h1>';

$pageHTML .= '<table border="1">';

// Récupération de toutes les équipes
$Jouers = getAllP13_Jouer();

// Affichage des données sous forme de tableau HTML
$pageHTML .= "<tr><th>Id Equipe</th><th>Id Joueur</th><th>Début Contrat</th><th>Fin Contrat</th></tr>";
foreach($Jouers as $Jouer) {
    $pageHTML .= "<tr>";
    $pageHTML .= intoBalise("td", $Jouer['eq_id']);
    $pageHTML .= intoBalise("td", $Jouer['j_id']);
    $pageHTML .= intoBalise("td", $Jouer['debutcontrat']);
    $pageHTML .= intoBalise("td", $Jouer['fincontrat']);

    $pageHTML .= intoBalise("tr", "");
}

$pageHTML .= intoBalise("table", "");
$pageHTML .="</br>";$pageHTML .="</br>";
$pageHTML .= intoBalise2("a", "Ajouter une nouvelle équipe", array('href' => 'nouvelleEquipe.php'));
$pageHTML .="</br>";$pageHTML .="</br>";
$pageHTML .= intoBalise2("a", "Ajouter un nouveau joueur", array('href' => 'nouveauJoueur.php'));
$pageHTML .="</br>";$pageHTML .="</br>";
$pageHTML .= intoBalise2("a", "Modifier une équipe", array('href' => 'modifierEquipe.php'));
$pageHTML .="</br>";$pageHTML .="</br>";
$pageHTML .= intoBalise2("a", "Modifier un joueur", array('href' => 'modifierJoueur.php'));
$pageHTML .="</br>";$pageHTML .="</br>";
$pageHTML .= intoBalise2("a", "Retour à l'accueil", array('href' => 'index.php'));


$pageHTML .= getFinHTML();
echo $pageHTML;
?>