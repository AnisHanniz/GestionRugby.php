<?php
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'fonctions.php';
    
    // Récupération des données du formulaire
    $Equipe = array(
    'eq_id' => $_POST['id']
);
if (isset($_POST['id'])) {
    $Equipe['id'] = $_POST['id'];
}


    
    // Insertion des données dans la base de données
    $Equipe['eq_id'] = (int)substr($Equipe['eq_id'], 0, 13); // Cast eq_id to an integer
    $resultat = deleteP13_equipe($Equipe['eq_id']);
    
    // Affichage d'un message de confirmation
    if(!isset($resultat['eq_id'])) {
    echo "L'équipe a été supprimée avec succès.";
    echo '<br><a href="tableAcceuilEquipe.php">Retourner à la liste des équipes</a>';
} else {
    echo "Une erreur est survenue lors de la suppression de l'équipe.";
    echo '<br><a href="tableAcceuilEquipe.php">Retourner à la liste des équipes</a>';
}
}
?>