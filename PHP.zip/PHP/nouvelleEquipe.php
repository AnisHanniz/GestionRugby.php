<?php
require 'fonctions.php';

$pageHTML = getDebutHTML("Nouvelle équipe", "style");

// Ajout d'un titre
$pageHTML .= '<h1>Création d\'une nouvelle équipe</h1>';

// Création du formulaire
$pageHTML .= '<form action="traitementAjoutEquipe.php" method="post">';
$pageHTML .= '<label for="id">id de l\'équipe: </label>';
$pageHTML .= '<input type="number" id="id" name="id"><br>';
$pageHTML .= '<label for="nom">Nom de l\'équipe : </label>';
$pageHTML .= '<input type="text" id="nom" name="nom"><br>';
$pageHTML .= '<label for="date">Date de création : </label>';
$pageHTML .= '<input type="date" id="date" name="date"><br>';
$pageHTML .= '<label for="budget">Budget annuel : </label>';
$pageHTML .= '<input type="number" id="budget" name="budget"><br>';
$pageHTML .= '<input type="submit" value="Créer">';
$pageHTML .= '</form>';

$pageHTML .="</br>";$pageHTML .="</br>";
$pageHTML .= intoBalise2("a", "Retour à la liste d'équipes", array('href' => 'tableAcceuilEquipe.php'));

$pageHTML .="</br>";$pageHTML .="</br>";
$pageHTML .= intoBalise2("a", "Retour à l'accueil", array('href' => 'index.php'));
$pageHTML .= '</form>';

$pageHTML .= getFinHTML();
echo $pageHTML;
?>
