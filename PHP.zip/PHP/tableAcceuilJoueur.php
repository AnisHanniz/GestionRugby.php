<?php
require 'fonctions.php';

$pageHTML = getDebutHTML("Joueur", "style");

// ajout d'un titre
$pageHTML .= '<h1>Table Joueur</h1>';

$pageHTML .= "</br>";
$pageHTML .= "</br>";
$pageHTML .= intoBalise2("a", "Ajouter un nouveau joueur", array('href' => 'nouveauJoueur.php'));
$pageHTML .= "</br>";
$pageHTML .= "</br>";
$pageHTML .= intoBalise2("a", "Modifier un joueur", array('href' => 'modifierJoueur.php'));
$pageHTML .= "</br>";
$pageHTML .= "</br>";
$pageHTML .= intoBalise2("a", "Retour à l'accueil", array('href' => 'index.php'));
$pageHTML .= intoBalise("table", "");
$pageHTML .= "</br>";
$pageHTML .= "</br>";

$pageHTML .= '<table border="1">';

// Récupération de toutes les équipes
$joueurs = getAllP13_Joueur();

$jouer = getAllP13_jouer();
$equipe = getAllP13_equipe();

// Affichage des données sous forme de tableau HTML
$pageHTML .= "<tr><th>Identifiant</th><th>Nom</th><th>Prénom</th><th>Date de naissance</th><th>Poste</th><th>Rôle</th><th>Équipe</th><th>Supprimer</th></tr>";
foreach ($joueurs as $joueur) {
    $pageHTML .= "<tr class='joueur'>";
    $pageHTML .= intoBalise("td", $joueur['j_id']);
    $pageHTML .= intoBalise("td", $joueur['j_nom']);
    $pageHTML .= intoBalise("td", $joueur['j_prenom']);
    $pageHTML .= intoBalise("td", $joueur['j_daten']);
    $pageHTML .= intoBalise("td", $joueur['j_poste']);
    $pageHTML .= intoBalise("td", $joueur['j_role']);
    $idJoueur = $joueur['j_id'];
    $nomEquipe = '';
    foreach ($jouer as $j) {
        if ($j['j_id'] == $idJoueur) {
            $idEquipe = $j['eq_id'];
            foreach ($equipe as $e) {
                if ($e['eq_id'] == $idEquipe) {
                    $nomEquipe = $e['eq_nom'];
                }
            }
        }
    }
    $pageHTML .= intoBalise("td", $nomEquipe);
    $pageHTML .= '<td><form action="traitementSuppJoueur.php" method="post">';
    $pageHTML .= '<input type="hidden" name="id" value="' . $joueur['j_id'] . '">';
    $pageHTML .= '<input type="submit" value="-">';
    $pageHTML .= '</form></td>';
    $pageHTML .= "</tr>";
}
$pageHTML .= '</table>';
$pageHTML .= getFinHTML();
echo $pageHTML;
?>
