<?php
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'fonctions.php';
    
    // Récupération des données du formulaire
    $Equipe = array(
    'eq_id' => $_POST['id'],
    'nom' => $_POST['nom'],
    'date' => $_POST['date'],
    'budget' => $_POST['budget']
);
if (isset($_POST['nom'])) {
    $Equipe['nom'] = $_POST['nom'];
}


    
    // Insertion des données dans la base de données
    $Equipe['eq_id'] = (int)substr($Equipe['eq_id'], 0, 13); // Cast eq_id to an integer
    $resultat = updateP13_equipe($Equipe);
    
    // Affichage d'un message de confirmation
    if(isset($resultat['eq_id'])) {
    echo "L'équipe a été modifiée avec succès.";
    echo '<br><a href="tableAcceuilEquipe.php">Retourner à la liste des équipes</a>';
} else {
    echo "Une erreur est survenue lors de la modification de l'équipe.";
    echo '<br><a href="tableAcceuilEquipe.php">Retourner à la liste des équipes</a>';
}
}
?>