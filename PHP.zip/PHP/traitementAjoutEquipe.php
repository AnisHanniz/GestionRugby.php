<?php
require 'fonctions.php';

$pageHTML = getDebutHTML("Joueur", "style");

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Récupération des données du formulaire
    $Equipe = array(
        'eq_id' => $_POST['id'],
        'nom' => $_POST['nom'],
        'date' => $_POST['date'],
        'budget' => $_POST['budget']
    );
    if (isset($_POST['nom'])) {
        $Equipe['nom'] = $_POST['nom'];
    }
    
    // Insertion des données dans la base de données
    $Equipe['eq_id'] = (int)substr($Equipe['eq_id'], 0, 13); // Cast eq_id to an integer
    $resultat = insertP13_equipe($Equipe);
    
    // Affichage d'un message de confirmation
    if(isset($resultat['eq_id'])) {
        $pageHTML .= intoBalise('p', "L'équipe a été ajoutée avec succès.");
        $pageHTML .= "<br><a href=\"" . "tableAcceuilEquipe.php" . "\">Retourner à la liste des équipes</a>";
    } else {
        $pageHTML .= intoBalise('p', "Une erreur est survenue lors de l'ajout de l'équipe.");
        $pageHTML .= "<br><a href=\"" . "tableAcceuilEquipe.php" . "\">Retourner à la liste des équipes</a>";
    }
} else {
    $pageHTML .= intoBalise('p', "La méthode HTTP utilisée n'est pas correcte.");
}

$pageHTML .= getFinHTML();
echo $pageHTML;
?>
