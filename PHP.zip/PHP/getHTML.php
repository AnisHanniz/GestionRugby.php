<?php

function getDebutHTML(string $title = "Title content", string $css = "style"): string {
    $html = '<!DOCTYPE html>
    <html lang="fr">
        <head>
            <meta charset="UTF-8">
            <title>'.$title.'</title>
            <link rel="stylesheet" type="text/css" href="'.$css.'.css">
        </head>
        <body>';
    return $html;
}



function getFinHTML(): string {
	return "</body></html>"; 
}


function intoBalise(string $nomElement, string $contenuElement): string {
	$balise="<".$nomElement ; 
	if($contenuElement == ""){
		return $balise." />";
	}else{
		return $balise.">".$contenuElement."</".$nomElement.">";
	}
}

/*
echo intoBalise("h1","Coucou")."\n"; 
echo intoBalise("br","")."\n";*/

function intoBalise2(string $nomElement, string $contenuElement, array $params=null): string{
	$balise="<".$nomElement ; 
	if($params){
		foreach ($params as $key => $value) {
			$balise .=" ".$key."='".$value."'";
		}
	}
	$balise .= ">";

	if($contenuElement == ""){
		$balise .=" />";
	}else{
        $balise .= $contenuElement."</".$nomElement.">"; 
    }
    return $balise ; 
}
/*
echo intoBalise2("p","mots à la suite", array('class'=>'rouge', 'id'=>'cle1'))."\n";*/
?>