<?php
require 'fonctions.php';

$pageHTML = getDebutHTML("Modification Joueur", "styleForm");

// Ajout d'un titre
$pageHTML .= '<h1>Modification Joueur</h1>';
// Création du formulaire
$pageHTML .= '<form action="traitementModifJoueur.php" method="post">';
$pageHTML .= '<label for="id">id du joueur: </label>';
$pageHTML .= '<input type="number" id="id" name="id"><br>';
$pageHTML .= '<label for="nom">Nom du joueur : </label>';
$pageHTML .= '<input type="text" id="nom" name="nom"><br>';
$pageHTML .= '<label for="nom">Prénom du joueur : </label>';
$pageHTML .= '<input type="text" id="prenom" name="prenom"><br>';
$pageHTML .= '<label for="date">Date de naissance : </label>';
$pageHTML .= '<input type="date" id="date" name="date"><br>';
$pageHTML .= '<label for="poste">Poste : </label>';
$pageHTML .= '<input type="number" id="poste" name="poste"><br>';
$pageHTML .= '<label for="role">Role : </label>';
$pageHTML .= '<input type="text" id="role" name="role"><br>';
$pageHTML .= '<input type="submit" value="Confirmer">';
$pageHTML .= '</form>';

$pageHTML .="</br>";$pageHTML .="</br>";
$pageHTML .= intoBalise2("a", "Retour à la table Joueur", array('href' => 'tableAcceuilJoueur.php'));
$pageHTML .="</br>";$pageHTML .="</br>";
$pageHTML .= intoBalise2("a", "Retour à l'accueil", array('href' => 'index.php'));
$pageHTML .= '</form>';

$pageHTML .= getFinHTML();
echo $pageHTML;
?>
