﻿ <?php

/* TODO compléter les variables d'environnement avec les bonnes valeurs*/

$host='localhost';
$dbName='postgres';
$dbUser='postgres';
$dbPassword='deesse90';
