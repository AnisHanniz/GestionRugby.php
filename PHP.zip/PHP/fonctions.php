<?php

function connexion() {
    include 'monEnv.php';
    /** TODO renseigner $strConnex à l'aide de $_ENV configuré dans monEnv.php */
    $strConnex = "host=$host dbname=$dbName user=$dbUser password=$dbPassword";
    $ptrDB = pg_connect($strConnex);
    return $ptrDB;
}

function getDebutHTML(string $title = "Title content", string $css = "style"): string {
    $html = '<!DOCTYPE html>
    <html lang="fr">
        <head>
            <meta charset="UTF-8">
            <title>'.$title.'</title>
            <link rel="stylesheet" type="text/css" href="'.$css.'.css">
        </head>
        <body>';
    return $html;
}



function getFinHTML(): string {
	return "</body></html>"; 
}


function intoBalise(string $nomElement, string $contenuElement): string {
	$balise="<".$nomElement ; 
	if($contenuElement == ""){
		return $balise." />";
	}else{
		return $balise.">".$contenuElement."</".$nomElement.">";
	}
}

/*
echo intoBalise("h1","Coucou")."\n"; 
echo intoBalise("br","")."\n";*/

function intoBalise2(string $nomElement, string $contenuElement, array $params=null): string{
	$balise="<".$nomElement ; 
	if($params){
		foreach ($params as $key => $value) {
			$balise .=" ".$key."='".$value."'";
		}
	}
	$balise .= ">";

	if($contenuElement == ""){
		$balise .=" />";
	}else{
        $balise .= $contenuElement."</".$nomElement.">"; 
    }
    return $balise ; 
}
/*
echo intoBalise2("p","mots à la suite", array('class'=>'rouge', 'id'=>'cle1'))."\n";*/

/**
 * getP13_joueurById
 * @param string $idn
 * @return array tableau associatif associé à la collecivité
 * TODO
 */
function getP13_joueurById(string $id) : array {
    $ptrDB = connexion();

    $query = "SELECT * FROM P13_joueur WHERE j_id = $1";

    /* TODO préparer la requête avec la fonction pg_prepare(...) ici */
    $resu = pg_prepare($ptrDB, "reqPrepSelectById", $query);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectById", array($id));

    if (isset($ptrQuery))
        /* TODO récupérer le tableau associatif avec pg_fetch_assoc dans $resu */
    $resu = pg_fetch_assoc($ptrQuery);

        if (empty($resu))
            $resu =  array("message" => "Identifiant de  non valide : $id");
    /* TODO libérer les ressources avec pg_free_result() ici */
     pg_free_result($ptrQuery);
    /* TODO fermer la connexion avec pg_close() ici */
    pg_close($ptrDB);

    return $resu;
}

function getAllP13_joueur() : array {
    $ptrDB = connexion();

    $query = "SELECT * FROM P13_joueur ORDER BY j_id";
    pg_prepare($ptrDB, "reqPrepSelectAll", $query);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectAll", array());

    $resu = array();

    if (isset($ptrQuery)) {
        /* TODO traitement des lignes du résultats une à une ici */
        $resu = pg_fetch_all($ptrQuery);
    }
    pg_free_result($ptrQuery);
    pg_close($ptrDB);
    return $resu;
}

function insertP13_joueur(array $Joueur) : array {
    $ptrDB = connexion();

    /* TODO préparation et exécution de la requête INSERT ici */
     $query = "INSERT INTO P13_joueur (j_id,j_nom,j_prenom,j_daten, j_poste,j_role) VALUES ($1, $2, $3, $4,$5,$6)";
     pg_prepare($ptrDB, "reqPrepInsert", $query);
     pg_execute($ptrDB, "reqPrepInsert", $Joueur);

    return getP13_joueurById($Joueur['j_id']);
}

function updateP13_Joueur(array $Joueur) {
    $ptrDB = connexion();

    // Cast eq_id to an integer
    $Joueur['j_id'] = (int)substr($Joueur['j_id'], 0, 13);

    /* TODO préparation et exécution de la requête UPDATE ici */
    $query = "UPDATE P13_Joueur SET j_nom = $1,j_prenom = $2,j_daten = $3::date, j_poste = $4, j_role = $5 WHERE j_id = $6";
    pg_prepare($ptrDB, "reqPrepUpdate", $query);
    pg_execute($ptrDB, "reqPrepUpdate", array($Joueur['nom'], $Joueur['prenom'], $Joueur['date'], $Joueur['poste'], $Joueur['role'], $Joueur['j_id']));

    return getP13_JoueurById($Joueur['j_id']);
}

function deleteP13_joueur(int $id) { // the parameter should be an integer
    $ptrDB = connexion();

    /* TODO préparation et exécution de la requête DELETE ici */
    $query = "DELETE FROM P13_joueur WHERE j_id = $1";
    pg_prepare($ptrDB, "reqPrepDelete", $query);
    $result = pg_execute($ptrDB, "reqPrepDelete", array($id));
    
    // TODO vérifier si la suppression a réussi
    // On peut vérifier avec pg_affected_rows si une ligne a été affectée par la requête DELETE
    // Si pg_affected_rows renvoie 0, la suppression a échoué
    if (!pg_affected_rows($result) === 0) {
        // TODO gérer le cas où la suppression a échoué
        // On peut utiliser pg_last_error pour récupérer l'erreur SQL exacte
        $erreur = pg_last_error($ptrDB);
        echo "Erreur lors de la suppression du joueur : $erreur";
    }
    
    // TODO libérer les ressources avec pg_free_result() ici
    // Attention, pg_free_result() ne s'utilise pas avec DELETE
    // Il faut plutôt utiliser pg_close() pour fermer la connexion à la base de données
    pg_close($ptrDB);
    return $result;
}


/**
 * getP13_jouerById
 * @param string $idn
 * TODO
 */
function getP13_jouerByIdEquipe(string $id) : array {
    $ptrDB = connexion();

    $query = "SELECT * FROM P13_jouer WHERE eq_id = $1";

    /* TODO préparer la requête avec la fonction pg_prepare(...) ici */
    $resu = pg_prepare($ptrDB, "reqPrepSelectById", $query);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectById", array($id));

    if (isset($ptrQuery))
        /* TODO récupérer le tableau associatif avec pg_fetch_assoc dans $resu */
    $resu = pg_fetch_assoc($ptrQuery);

        if (empty($resu))
            $resu =  array("message" => "Identifiant de  non valide : $id");
    /* TODO libérer les ressources avec pg_free_result() ici */
     pg_free_result($ptrQuery);
    /* TODO fermer la connexion avec pg_close() ici */
    pg_close($ptrDB);

    return $resu;
}
function getP13_jouerByIdJoueur(string $id) : array {
    $ptrDB = connexion();

    $query = "SELECT * FROM P13_jouer WHERE j_id = $1";

    /* TODO préparer la requête avec la fonction pg_prepare(...) ici */
    $resu = pg_prepare($ptrDB, "reqPrepSelectById", $query);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectById", array($id));

    if (isset($ptrQuery))
        /* TODO récupérer le tableau associatif avec pg_fetch_assoc dans $resu */
    $resu = pg_fetch_assoc($ptrQuery);

        if (empty($resu))
            $resu =  array("message" => "Identifiant de  non valide : $id");
    /* TODO libérer les ressources avec pg_free_result() ici */
     pg_free_result($ptrQuery);
    /* TODO fermer la connexion avec pg_close() ici */
    pg_close($ptrDB);

    return $resu;
}
function getAllP13_jouer() : array {
    $ptrDB = connexion();

    $query = "SELECT * FROM P13_jouer";
    pg_prepare($ptrDB, "reqPrepSelectAll", $query);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectAll", array());

    $resu = array();

    if (isset($ptrQuery)) {
        /* TODO traitement des lignes du résultats une à une ici */
        $resu = pg_fetch_all($ptrQuery);
    }
    pg_free_result($ptrQuery);
    pg_close($ptrDB);
    return $resu;
}

function insertP13_jouer(array $jouer) : array {
    $ptrDB = connexion();

    /* TODO préparation et exécution de la requête INSERT ici */
     $query = "INSERT INTO P13_jouer (eq_id,j_id,debutcontrat,fincontrat) VALUES ($1, $2, $3, $4)";
     pg_prepare($ptrDB, "reqPrepInsert", $query);
     pg_execute($ptrDB, "reqPrepInsert", $jouer);

    return getP13_jouerByIdEquipe($jouer['eq_id']);
}

function updateP13_jouer(array $jouer) {
    $ptrDB = connexion();

    // Cast eq_id to an integer
    $jouer['j_id'] = (int)substr($jouer['j_id'], 0, 13);

    /* TODO préparation et exécution de la requête UPDATE ici */
    $query = "UPDATE P13_jouer SET eq_id = $1,j_id = $2,debutcontrat = $3::date, fincontrat = $4::date WHERE eq_id = $5";
    pg_prepare($ptrDB, "reqPrepUpdate", $query);
    pg_execute($ptrDB, "reqPrepUpdate", array($jouer['eq_id'], $jouer['j_id'], $jouer['debutcontrat'], $jouer['fincontrat']));

    return getP13_jouerByIdEquipe($jouer['eq_id']);
}

function deleteP13_jouer(int $id) { // the parameter should be an integer
    $ptrDB = connexion();

    /* TODO préparation et exécution de la requête DELETE ici */
    $query = "DELETE FROM P13_jouer WHERE j_id = $1";
    pg_prepare($ptrDB, "reqPrepDelete2", $query);
    $result = pg_execute($ptrDB, "reqPrepDelete2", array($id));

    // TODO vérifier si la suppression a réussi
    // On peut vérifier avec pg_affected_rows si une ligne a été affectée par la requête DELETE
    // Si pg_affected_rows renvoie 0, la suppression a échoué
    if (pg_affected_rows($result) === 0) {
        // TODO gérer le cas où la suppression a échoué
        // On peut utiliser pg_last_error pour récupérer l'erreur SQL exacte
        $erreur = pg_last_error($ptrDB);
        echo "Erreur lors de la suppression des données de participation du joueur : $erreur";
    }
    
    // TODO libérer les ressources avec pg_free_result() ici
    // Attention, pg_free_result() ne s'utilise pas avec DELETE
    // Il faut plutôt utiliser pg_close() pour fermer la connexion à la base de données
    pg_close($ptrDB);
}


/**
 * getP13_equipeById
 * @param string $idn
 * @return array tableau associatif associé à la collecivité
 * TODO
 */
function getP13_equipeById(string $id) : array {
    $ptrDB = connexion();

    $query = "SELECT * FROM P13_equipe WHERE eq_id = $1";

    /* TODO préparer la requête avec la fonction pg_prepare(...) ici */
    $resu = pg_prepare($ptrDB, "reqPrepSelectById", $query);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectById", array($id));

    if (isset($ptrQuery))
        /* TODO récupérer le tableau associatif avec pg_fetch_assoc dans $resu */
    $resu = pg_fetch_assoc($ptrQuery);

        if (empty($resu))
            $resu =  array("message" => "Identifiant  non valide : $id");
    /* TODO libérer les ressources avec pg_free_result() ici */
     pg_free_result($ptrQuery);
    /* TODO fermer la connexion avec pg_close() ici */
    pg_close($ptrDB);

    return $resu;
}
function getId_ByEquipe(string $equipe) : int {
    $ptrDB = connexion();

    $query = "SELECT eq_id FROM P13_equipe WHERE eq_nom = $1";

    /* Préparer la requête avec la fonction pg_prepare(...) ici */
    $resu = pg_prepare($ptrDB, "reqPrepSelectById", $query);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectById", array($equipe));

    if (isset($ptrQuery)) {
        /* Récupérer le tableau associatif avec pg_fetch_assoc dans $resu */
        $resu = pg_fetch_assoc($ptrQuery);
    }

    if (empty($resu)) {
        $resu =  array("message" => "Nom d'équipe non valide : $equipe");
    }

    /* Libérer les ressources avec pg_free_result() ici */
    pg_free_result($ptrQuery);

    /* Fermer la connexion avec pg_close() ici */
    pg_close($ptrDB);

    return (int)$resu['eq_id'];
}


function getAllP13_equipe() : array {
    $ptrDB = connexion();

    $query = "SELECT * FROM P13_equipe";
    pg_prepare($ptrDB, "reqPrepSelectAll", $query);
    $ptrQuery = pg_execute($ptrDB, "reqPrepSelectAll", array());

    $resu = array();

    if (isset($ptrQuery)) {
        /* TODO traitement des lignes du résultats une à une ici */
        $resu = pg_fetch_all($ptrQuery);
    }
    pg_free_result($ptrQuery);
    pg_close($ptrDB);
    return $resu;
}

function insertP13_equipe(array $Equipe) : array {
    $ptrDB = connexion();

    // Cast eq_id to an integer
    $Equipe['eq_id'] = (int)substr($Equipe['eq_id'], 0, 13);

    /* TODO préparation et exécution de la requête INSERT ici */
    $query = "INSERT INTO P13_equipe (eq_id,eq_nom,eq_dateCrea,eq_budgetAn) VALUES ($1, $2, $3, $4)";
    pg_prepare($ptrDB, "reqPrepInsert", $query);
    pg_execute($ptrDB, "reqPrepInsert", $Equipe);

    return getP13_equipeById($Equipe['eq_id']);
}


function updateP13_equipe(array $Equipe) {
    $ptrDB = connexion();

    // Cast eq_id to an integer
    $Equipe['eq_id'] = (int)substr($Equipe['eq_id'], 0, 13);

    /* TODO préparation et exécution de la requête UPDATE ici */
    $query = "UPDATE P13_equipe SET eq_nom = $1, eq_dateCrea = $2::date, eq_budgetAn = $3 WHERE eq_id = $4";
    pg_prepare($ptrDB, "reqPrepUpdate", $query);
    pg_execute($ptrDB, "reqPrepUpdate", array($Equipe['nom'], $Equipe['date'], $Equipe['budget'], $Equipe['eq_id']));

    return getP13_equipeById($Equipe['eq_id']);
}


function deleteP13_equipe(string $id) {
    $ptrDB = connexion();

    /* TODO préparation et exécution de la requête DELETE ici */
    $query = "DELETE FROM P13_equipe WHERE eq_id = $1";
     pg_prepare($ptrDB, "reqPrepDelete", $query);
     pg_execute($ptrDB, "reqPrepDelete", array($id));

}
function getOptionsFromTable(string $tableName, string $colName, string $nomVar): string {
    $lesOptions ="";
    $ptrDB = connexion();
    $query = "SELECT $colName FROM $tableName";
    $ptrQuery = pg_query($ptrDB, $query);
    while($row = pg_fetch_assoc($ptrQuery)) {
        $valeur = trim($row[$colName]);
        $lesOptions .= "<option value='$valeur' ";
        if (isset($_REQUEST[$nomVar]) && $_REQUEST[$nomVar]==$valeur)
            $lesOptions .= "selected='selected' ";
        $lesOptions .= ">$valeur</option>\n";
    }
    pg_free_result($ptrQuery);
    pg_close($ptrDB);
    return $lesOptions;
}
