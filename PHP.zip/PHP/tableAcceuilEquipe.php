<?php
require 'fonctions.php';



$pageHTML = getDebutHTML("Equipe", "style");

// ajout d'un titre
$pageHTML .= '<h1>Table equipe</h1>';

$pageHTML .= '<table border="1">';

// Récupération de toutes les équipes
$equipes = getAllP13_equipe();

// Affichage des données sous forme de tableau HTML
$pageHTML .= "<tr><th>Identifiant</th><th>Nom</th><th>Date de création</th><th>Budget annuel</th><th>Supprimer</th></tr>";
foreach($equipes as $equipe) {
    $pageHTML .= "<tr>";
    $pageHTML .= intoBalise("td", $equipe['eq_id']);
    $pageHTML .= intoBalise("td", $equipe['eq_nom']);
    $pageHTML .= intoBalise("td", $equipe['eq_datecrea']);
    $pageHTML .= intoBalise("td", $equipe['eq_budgetan']);
    $pageHTML .= '<td><form action="traitementSuppEquipe.php" method="post">';
    $pageHTML .= '<input type="hidden" name="id" value="' . $equipe['eq_id'] . '">';
    $pageHTML .= '<input type="submit" value="-">';
    $pageHTML .= '</form></td>';

    $pageHTML .= intoBalise("tr", "");
}

$pageHTML .= intoBalise("table", "");
$pageHTML .="</br>";$pageHTML .="</br>";
$pageHTML .= intoBalise2("a", "Ajouter une nouvelle équipe", array('href' => 'nouvelleEquipe.php'));
$pageHTML .="</br>";$pageHTML .="</br>";
$pageHTML .= intoBalise2("a", "Modifier une équipe", array('href' => 'modifierEquipe.php'));
$pageHTML .="</br>";$pageHTML .="</br>";
$pageHTML .= intoBalise2("a", "Retour à l'accueil", array('href' => 'index.php'));


$pageHTML .= getFinHTML();
echo $pageHTML;
?>