
<?php
require 'fonctions.php';

$pageHTML = getDebutHTML("Accueil", "style");

$pageHTML .= intoBalise('body', '');

$pageHTML .='<img src="bg1.png"\>';

$pageHTML .= intoBalise('h1', 'Qu\'est-ce que le Rugby?');

$pageHTML .= intoBalise2('p', '<b>Le Rugby est un sport pratiqué avec un ballon ovale, opposant deux équipes de quinze (rugby à quinze) ou treize (rugby ou, parfois, jeu à treize) joueurs, chacune cherchant à marquer plus de points que l\'autre en portant le ballon dans l\'en-but de l\'adversaire ou en le faisant passer, d\'un coup de pied, au-dessus de la barre transversale entre les poteaux de but.</b>', array());

$pageHTML .= intoBalise('br', '');

$pageHTML .= intoBalise('ul', '');

$pageHTML .= intoBalise('li', '<a href="tableAcceuilEquipe.php">Contenu de la table Equipe</a>', '');

$pageHTML .= intoBalise('li', '<a href="tableAcceuilJoueur.php">Contenu de la table Joueur</a>', '');

$pageHTML .= intoBalise('li', '<a href="nouvelleEquipe.php">Formulaire d\'insertion pour la table Equipe</a>', '');

$pageHTML .= intoBalise('li', '<a href="nouveauJoueur.php">Formulaire d\'insertion pour la table Joueur</a>', '');

$pageHTML .= intoBalise('li', '<a href="modifierEquipe.php">Modification de la table Equipe</a>', '');

$pageHTML .= intoBalise('li', '<a href="modifierJoueur.php">Modification de la table Joueur</a>', '');

$pageHTML .= intoBalise('li', '<a href="tableAcceuilJouer.php">Consulter la table Jouer (Associations)</a>', '');

$pageHTML .= intoBalise('li', '<a href="ReadMe.php">ReadMe!</a>','');

$pageHTML .= intoBalise('/ul', '');

$pageHTML .= intoBalise('/body', '');

$pageHTML .= getFinHTML();

echo $pageHTML;
?>