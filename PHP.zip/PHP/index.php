
<?php
require 'fonctions.php';

$pageHTML = getDebutHTML("Accueil", "style");

$pageHTML .= intoBalise('body', '');

$pageHTML .= intoBalise('h1', 'Application de Gestion d\'équipes de Rugby');

$pageHTML .= intoBalise('br', '');

$pageHTML .= intoBalise('ul', '');

$pageHTML .= intoBalise('li', '<a href="tableAcceuilEquipe.php">Consulter les Équipes</a>', '');

$pageHTML .= intoBalise('li', '<a href="tableAcceuilJoueur.php">Consulter les Joueurs</a>', '');

$pageHTML .= intoBalise('li', '<a href="nouvelleEquipe.php">Nouvelle Équipe</a>', '');

$pageHTML .= intoBalise('li', '<a href="nouveauJoueur.php">Nouveau Joueur</a>', '');

$pageHTML .= intoBalise('li', '<a href="modifierEquipe.php">Modifier une Équipe</a>', '');

$pageHTML .= intoBalise('li', '<a href="modifierJoueur.php">Modifier un Joueur</a>', '');

$pageHTML .= intoBalise('li', '<a href="tableAcceuilJouer.php">Consulter les Associations</a>', '');

$pageHTML .= intoBalise('/ul', '');

$pageHTML .= intoBalise('/body', '');

$pageHTML .= getFinHTML();

echo $pageHTML;
?>
