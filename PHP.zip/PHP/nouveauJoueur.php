<?php
require 'fonctions.php';

$pageHTML = getDebutHTML("Nouveau Joueur", "style");

// Ajout d'un titre
$pageHTML .= '<h1>Création d\'un nouveau joueur</h1>';

// Création du formulaire
$pageHTML .= '<form action="traitementAjoutJoueur.php" method="post">';
$pageHTML .= '<label for="id">id du joueur: </label>';
$pageHTML .= '<input type="number" id="id" name="id"><br>';
$pageHTML .= '<label for="nom">Nom du joueur : </label>';
$pageHTML .= '<input type="text" id="nom" name="nom"><br>';
$pageHTML .= '<label for="nom">Prénom du joueur : </label>';
$pageHTML .= '<input type="text" id="prenom" name="prenom"><br>';
$pageHTML .= '<label for="date">Date de naissance : </label>';
$pageHTML .= '<input type="date" id="date" name="date"><br>';
$pageHTML .= '<label for="poste">Poste : </label>';
$pageHTML .= '<input type="number" id="poste" name="poste"><br>';
$pageHTML .= '<label for="role">Role : </label>';
$pageHTML .= '<input type="text" id="role" name="role"><br>';
$pageHTML .= '<label for="equipe">Equipe : </label>';
$pageHTML .= "<select name = 'Equipe'>";
$pageHTML .= getOptionsFromTable("p13_equipe","eq_nom","Equipe");
$pageHTML .= '</select><br>';

$pageHTML .= '<label for="date">Début contrat : </label>';
$pageHTML .= '<input type="date" id="dateDC" name="dateDC"><br>';

$pageHTML .= '<label for="date">Fin contrat : </label>';
$pageHTML .= '<input type="date" id="dateFC" name="dateFC"><br>';


$pageHTML .= '<input type="submit" value="Créer">';
$pageHTML .= '</form>';
$pageHTML .="</br>";$pageHTML .="</br>";
$pageHTML .= intoBalise2("a", "Retour à la liste de Joueurs", array('href' => 'tableAcceuilJoueur.php'));
$pageHTML .="</br>";$pageHTML .="</br>";
$pageHTML .= intoBalise2("a", "Retour à l'accueil", array('href' => 'index.php'));
$pageHTML .= '</form>';
$pageHTML .= getFinHTML();
echo $pageHTML;
?>