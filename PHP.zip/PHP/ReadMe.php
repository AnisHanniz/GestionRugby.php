
<?php
require 'fonctions.php';

$pageHTML = getDebutHTML("Accueil", "style");

$pageHTML .= intoBalise('body', '');
$pageHTML .= intoBalise('h1', 'READ ME');

$pageHTML .= intoBalise('p', "
Projet : Gestion d'équipes de Rugby<br>
!Attention!<br>
Veuillez suivre les étapes suivantes afin de visualiser correctement notre projet<br>
- Déplacer le dossier 'proj' dans les fichiers de votre serveur<br>
Dans notre cas, c'est un serveur local (WAMP)<br>
Nous avons déplacé 'proj' dans %wamp64/www/%<br>
- Création des tables dans votre base de donnée<br>
Veuillez executer le contenu du fichier 'P13_POSTGRE.sql'<br>
afin de créer et alimenter les tables p13_joueur,p13_equipe et p13_jouer.<br>
- Environnement de BDD<br>
Veuillez modifier monEnv.php comme suit, <br>
\$host='Le nom du serveur hôte';<br>
\$dbName='le nom de votre base de données';<br>
\$dbUser='Le nom d'utilisateur';<br>
\$dbPassword='Le mot de passe de votre bdd';<br>
<br><br><br>
- Bravo! Vous pouvez maintenant visualiser notre projet.<br>", '');

$pageHTML .="</br>";$pageHTML .="</br>";
$pageHTML .= intoBalise2("a", "Retour à l'accueil", array('href' => 'index.php'));

$pageHTML .= intoBalise('/body', '');

$pageHTML .= getFinHTML();

echo $pageHTML;
?>