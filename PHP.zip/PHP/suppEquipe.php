<?php
require 'fonctions.php';

$pageHTML = getDebutHTML("Suppression", "style");

// Ajout d'un titre
$pageHTML .= '<h1>Suppression d\'une équipe</h1>';

// Création du formulaire
$pageHTML .= '<form action="traitementSuppEquipe.php" method="post">';
$pageHTML .= '<label for="id">id de l\'équipe: </label>';
$pageHTML .= '<input type="number" id="id" name="id"><br>';
$pageHTML .= '<input type = "submit" value ="Supprimer"';
$pageHTML .= '</form>';

$pageHTML .= getFinHTML();
echo $pageHTML;
?>
