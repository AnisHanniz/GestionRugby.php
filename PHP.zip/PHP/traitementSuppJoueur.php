<?php
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'fonctions.php';
    
    // Récupération des données du formulaire
    $id = $_POST['id'];
    
    // Suppression des données dans la base de données
    // On commence par supprimer les données de participation du joueur dans la table P13_jouer
    $resultat2 = deleteP13_jouer($id);
    
    // Puis on supprime le joueur lui-même dans la table P13_joueur
    $resultat = deleteP13_joueur($id);
    
    // Affichage d'un message de confirmation 
        echo "Le joueur a été supprimé avec succès.";
        intoBalise2("a", "Retour à l'accueil", array('href' => 'index.php'));
}
?>